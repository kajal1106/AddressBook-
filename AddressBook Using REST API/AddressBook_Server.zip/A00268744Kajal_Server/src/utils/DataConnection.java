package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.hsqldb.HsqlException;

public class DataConnection {
	
	static Connection con = null;
	public static Connection connectionMethod() throws ClassNotFoundException, HsqlException, Exception  {
		// TODO Auto-generated method stub
		Class.forName("org.hsqldb.jdbc.JDBCDriver");
		 try {
			con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/oneDB", "SA", "");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Statement stmt = con.createStatement();
		
		stmt.executeUpdate("CREATE TABLE IF NOT EXISTS addressbook(id INTEGER IDENTITY, fname VARCHAR(32) NOT NULL, lname VARCHAR(32) NOT NULL , mobile INTEGER , gender VARCHAR(32),  address VARCHAR(220), city VARCHAR(32), email VARCHAR(32))" );

		return con;
	}

}
