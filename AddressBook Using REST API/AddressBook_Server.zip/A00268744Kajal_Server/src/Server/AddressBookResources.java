package Server;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;



@Path("/addressbooks")
public class AddressBookResources {
	@GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.TEXT_XML })
	public ArrayList<AddressBook> getContacts() throws SQLException, ClassNotFoundException{
		return AddressBookDao.INSTANCE.getContacts();
	}
	
	@GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON, MediaType.TEXT_XML})
	@Path("{id}")
	
	public ArrayList<AddressBook> getAddressBook(@PathParam("id") int id)throws NumberFormatException, SQLException, ClassNotFoundException {
		return AddressBookDao.INSTANCE.getAdressbook(id);
	}
	
	@POST
	@Produces({ MediaType.TEXT_HTML })
	@Consumes({ MediaType.APPLICATION_FORM_URLENCODED })
	public void postAddressbook(@FormParam("id") int id,
			@FormParam("fname") String fname,
			@FormParam("lname") String lname,
			@FormParam("mobile") int mobile,
			@FormParam("gender") String gender,
			@FormParam("address") String address,
			@FormParam("city") String city,
			@FormParam("email") String email) throws IOException, ClassNotFoundException, SQLException {
//			@Context HttpServletResponse servletResponse) 
			System.out.println(fname);
			
			AddressBook addressBook = new AddressBook();
			addressBook.setId(id);
			addressBook.setFname(fname);
			addressBook.setLname(lname);
			addressBook.setMobile(mobile);
			addressBook.setGender(gender);
			addressBook.setAddress(address);
			addressBook.setCity(city);
			addressBook.setEmail(email);
			
			AddressBookDao.INSTANCE.create(addressBook);
	}
	
	@DELETE
	@Produces(MediaType.TEXT_HTML)
	@Path("{id}")
	public void deleteAddressbook(@PathParam("id") int id) throws IOException, NumberFormatException, SQLException, ClassNotFoundException{
		System.out.println("Delete id:" +id); 
		AddressBookDao.INSTANCE.delete(id);
	}
	
	@PUT
	@Produces(MediaType.TEXT_HTML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Path("{id}")
	public void putAddressbook(@PathParam("id") int id,
			@FormParam("fname") String fname,
			@FormParam("lname") String lname,
			@FormParam("mobile") int mobile,
			@FormParam("gender") String gender,
			@FormParam("address") String address,
			@FormParam("city") String city,
			@FormParam("email") String email) throws ClassNotFoundException, SQLException {
//			@Context HttpServletResponse servletResponse) 
			System.out.println("PUT id = " + id);
			
			AddressBook addressBook = new AddressBook();
			addressBook.setId(id);
			addressBook.setFname(fname);
			addressBook.setLname(lname);
			addressBook.setMobile(mobile);
			addressBook.setGender(gender);
			addressBook.setAddress(address);
			addressBook.setCity(city);
			addressBook.setEmail(email);
			
			AddressBookDao.INSTANCE.update(addressBook, id);
			
	}
 }
