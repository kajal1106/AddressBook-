package Server;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hsqldb.HsqlException;



public enum AddressBookDao {
	INSTANCE;
	private ArrayList<AddressBook> addressbookArr;
	
	public ArrayList<AddressBook> getContacts() throws ClassNotFoundException, HsqlException, SQLException{

		addressbookArr = new ArrayList<AddressBook>();
		Class.forName("org.hsqldb.jdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/oneDB", "SA", "");
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from addressbook");
		while(rs.next()) {
			AddressBook addressBook1 = new AddressBook();
			addressBook1.setId(rs.getInt("id"));
			addressBook1.setFname(rs.getString("fname"));
			addressBook1.setLname(rs.getString("lname"));
			addressBook1.setMobile(rs.getInt("mobile"));
			addressBook1.setGender(rs.getString("gender"));
			addressBook1.setAddress(rs.getString("address"));
			addressBook1.setCity(rs.getString("city"));
			addressBook1.setEmail(rs.getString("email"));
			addressbookArr.add(addressBook1);		
		}

		return addressbookArr;
	}

	public ArrayList<AddressBook> getAdressbook(int id)throws ClassNotFoundException,HsqlException, SQLException {
		
		addressbookArr = new ArrayList<AddressBook>();
		Class.forName("org.hsqldb.jdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/oneDB", "SA", "");
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from addressbook where id = " +id);
		while(rs.next()) {
			AddressBook addressBook1 = new AddressBook();
			addressBook1.setId(rs.getInt("id"));
			addressBook1.setFname(rs.getString("fname"));
			addressBook1.setLname(rs.getString("lname"));
			addressBook1.setMobile(rs.getInt("mobile"));
			addressBook1.setGender(rs.getString("gender"));
			addressBook1.setAddress(rs.getString("address"));
			addressBook1.setCity(rs.getString("city"));
			addressBook1.setEmail(rs.getString("email"));
			addressbookArr.add(addressBook1);		
		}
		for(AddressBook a: addressbookArr) {
			System.out.print("ID:" + a.getId());
			System.out.print("Name:" + a.getFname() + a.getLname());
			System.out.print("Mobile" + a.getMobile());
		}
		return addressbookArr;
	}

	public void create(AddressBook addressbook) throws ClassNotFoundException, HsqlException,SQLException{
		// TODO Auto-generated method stub
		Class.forName("org.hsqldb.jdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/oneDB", "SA", "");
		Statement st = con.createStatement();
		st.executeUpdate("INSERT INTO addressbook values("+addressbook.getId()+",'"+addressbook.getFname()+"','"+addressbook.getLname()+"',"+addressbook.getMobile()+",'"+addressbook.getGender()+"','"+addressbook.getAddress()+"','"+addressbook.getCity()+"','"+addressbook.getEmail()+"')");
		st.close();
		con.close();
	}
	public void delete(int id) throws ClassNotFoundException, HsqlException, SQLException{
		// TODO Auto-generated method stub
		if(id>0) {
			Class.forName("org.hsqldb.jdbcDriver");
			Connection con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/oneDB", "SA", "");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("delete from addressbook where id=" + id);
			if (!rs.wasNull()) {
				System.out.println("Contacts Removed.");
			} else {

				System.out.println("Contacts Not Removed.");
			}
		} else {

			System.out.println("Id is wrong");
		}	}
	public void update(AddressBook addressbook, int id)throws ClassNotFoundException, HsqlException,SQLException{
		Class.forName("org.hsqldb.jdbcDriver");
		Connection con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/oneDB", "SA", "");
		String sql="UPDATE  addressbook SET fname=?,lname=?, mobile=?, Gender=?, address=?, city=?, email=? WHERE id= ? ";
		PreparedStatement statement;
		try {
			statement = con.prepareStatement(sql);
			statement.setString(1, addressbook.getFname());
			statement.setString(2, addressbook.getLname());
			statement.setInt(3, addressbook.getMobile());
			statement.setString(4, addressbook.getGender());
			statement.setString(5, addressbook.getAddress());
			statement.setString(6,addressbook.getCity());
			statement.setString(7, addressbook.getEmail());
			statement.setInt(8, id);
			
			int rowsUpdated = statement.executeUpdate();
			if(rowsUpdated>0) {
				System.out.println("An existing contact was updated successfully!");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}


