package client;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.SystemColor;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.hsqldb.HsqlException;
import org.hsqldb.Table;


import java.awt.Color;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class ViewWindow extends JFrame {

	private JPanel contentPane;
	private JComboBox searchbyfname;
	private JTable table;
	private ArrayList<AddressBook> addressbookList;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewWindow frame = new ViewWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public void show_table() {
		String[] columnnames = {"id","fname","lname","mobile","Gender","address","city","email"};
    	DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(columnnames);
		table.setModel(model);
		
		AddressbookClient addressbookClient = new AddressbookClient();
		try {
		addressbookList = addressbookClient.getContacts();
		} catch (IOException | URISyntaxException e) {
			JOptionPane.showMessageDialog(null, e);
		}
		for(AddressBook addressbook:addressbookList) {
			model.addRow(new Object[] {
					addressbook.getId(),addressbook.getFname(),
					addressbook.getLname(),addressbook.getMobile(),
					addressbook.getGender(),addressbook.getAddress(),
					addressbook.getCity(),addressbook.getEmail()
					});
		}	
	}
	public ViewWindow() {
		setTitle("View AddressBook");
		setBounds(100, 100, 815, 441);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setForeground(SystemColor.textHighlight);
		panel.setBorder(new EmptyBorder(5, 5, 5, 5));
		panel.setBackground(SystemColor.textHighlight);
		panel.setBounds(0, 0, 797, 398);
		contentPane.add(panel);
		
		JButton btnView = new JButton("View Contacts");
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String[] columnnames = {"id","fname","lname","mobile","Gender","address","city","email"};
		    	DefaultTableModel model = new DefaultTableModel();
				model.setColumnIdentifiers(columnnames);
				table.setModel(model);
				
				AddressbookClient addressbookClient = new AddressbookClient();
				try {
				addressbookList = addressbookClient.getContacts();
				} catch (IOException | URISyntaxException e1) {
					JOptionPane.showMessageDialog(null, e1);
				}
				for(AddressBook addressbook:addressbookList) {
					model.addRow(new Object[] {
							addressbook.getId(),addressbook.getFname(),
							addressbook.getLname(),addressbook.getMobile(),
							addressbook.getGender(),addressbook.getAddress(),
							addressbook.getCity(),addressbook.getEmail()
							});
				}	
			}
		});
		btnView.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnView.setBounds(630, 45, 144, 25);
		panel.add(btnView);
		
		JComboBox searchbyfname = new JComboBox();
		searchbyfname.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

			}
		});
		searchbyfname.addItem("Search By Name");
		searchbyfname.setBounds(21, 45, 597, 25);
		panel.add(searchbyfname);
		
		JLabel lblViewPersonalDetails = new JLabel("View Personal Details");
		lblViewPersonalDetails.setHorizontalAlignment(SwingConstants.CENTER);
		lblViewPersonalDetails.setForeground(Color.WHITE);
		lblViewPersonalDetails.setFont(new Font("Monospaced", Font.BOLD, 30));
		lblViewPersonalDetails.setBounds(199, 0, 406, 35);
		panel.add(lblViewPersonalDetails);
		
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBorder(new TitledBorder(null, "Database Content", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(10, 82, 777, 306);
		panel.add(panel_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 20, 757, 276);
		panel_1.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		
		AddressbookClient addressbookClient = new AddressbookClient();
		try {
		addressbookList = addressbookClient.getContacts();
		} catch (IOException | URISyntaxException e1) {
			JOptionPane.showMessageDialog(null, e1);
		}
		for(AddressBook addressbook:addressbookList) {
			searchbyfname.addItem(addressbook.getFname());
		}
		
		searchbyfname.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent arg0) {
				// TODO Auto-generated method stub
				if (arg0.getStateChange() == ItemEvent.SELECTED) {
					System.out.print(searchbyfname.getSelectedItem());  
					String[] columnnames = {"id","fname","lname","mobile","Gender","address","city","email"};
			    	DefaultTableModel model = new DefaultTableModel();
					model.setColumnIdentifiers(columnnames);
					table.setModel(model);
					
					AddressbookClient addressbookClient = new AddressbookClient();
					try {	
					addressbookList = addressbookClient.getContacts();
					} catch (IOException | URISyntaxException e1) {
						JOptionPane.showMessageDialog(null, e1);
					}
					for(AddressBook addressbook:addressbookList) {
						if(searchbyfname.getSelectedItem().equals(addressbook.getFname())) {
						model.addRow(new Object[] {
								addressbook.getId(),addressbook.getFname(),
								addressbook.getLname(),addressbook.getMobile(),
								addressbook.getGender(),addressbook.getAddress(),
								addressbook.getCity(),addressbook.getEmail()
								});
						}
						}
					//Do any operations you need to do when an item is selected.
			    } 
				
			}
			
		});

	}
}
