package client;

public class AddressBookExceptionHandler extends Exception{
String message;
	
	public AddressBookExceptionHandler(String errMessage){
		message = errMessage;
	}
	
	public String getMessage() {
			return message;
	}

}
