package client;

public class AddressBook {
	private int id;
	private String fname;
	private String lname;
	private int mobile;
	private String gender;
	private String address;
	private String city;
	private String email;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public static boolean validateId(String id2) throws AddressBookExceptionHandler {
		// TODO Auto-generated method stub
		boolean res = false;

		if (isNullOrEmpty(id2)) {
			throw new AddressBookExceptionHandler("ID Field can't be empty!");
		}
//
		else {

			try{
				int idInt = Integer.parseInt(id2);

				if(idInt<1) {
					throw new AddressBookExceptionHandler(" Id should be Less Than 1");
				}
				else if(idInt>=1 && idInt<=100) {
					res = true;
				}
				else {
					throw new AddressBookExceptionHandler(" Id should always be Greater Than 100");
				}
			}catch (NumberFormatException ex) {

				throw new AddressBookExceptionHandler("Entry for id must be numeric value");
			}
		}

		return res;	}	
	
	public static boolean validateName(String firstname) throws AddressBookExceptionHandler{
		// TODO Auto-generated method stub
		boolean res = false;

		if (isNullOrEmpty(firstname)) {
			throw new AddressBookExceptionHandler("Name field can't be empty");
		}

		else if(firstname.length() >= 1 && firstname.length() <=3) {
			throw new AddressBookExceptionHandler("Name Length can't be less than 4");
		}
		else if(firstname.length() >= 4 && firstname.length() <=15) {
			res = true;
		}
		else {
			throw new AddressBookExceptionHandler("name Length Greater than 15 Characters");
		}


		return res;	}

	
	private static boolean isNullOrEmpty(String str) {
		// TODO Auto-generated method stub
		if(str != null && !str.isEmpty())
			return false;
		return true;
	}
}
