package client;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;



public class AddressbookClient {
	public ArrayList<AddressBook> getContacts() throws URISyntaxException, ClientProtocolException, IOException{
		CloseableHttpResponse response = null;
		try {
			URI uri = new URIBuilder()
					.setScheme("http")
					.setHost("localhost")
					.setPort(8080)
					.setPath("/A00268744Kajal_Server/rest/addressbooks").build();
			System.out.println(uri.toString());
									
			//GET
			HttpGet httpGet = new HttpGet(uri);
			httpGet.setHeader("Accept", "application/xml");
			CloseableHttpClient httpClient = HttpClients.createDefault();
			response = httpClient.execute(httpGet);	
		
			HttpEntity entity = response.getEntity();
			String text = EntityUtils.toString(entity);
			System.out.println(text);
			
			ArrayList<AddressBook> addressbookList = new ParseAddressbook().doParseAddressBooks(text);
			
			return addressbookList;
			
		}finally {
			response.close();
		}
	}
	public ArrayList<AddressBook> getAddressBooks(int id) throws URISyntaxException, ClientProtocolException, IOException{
		CloseableHttpResponse response = null;
		try {
			URI uri = new URIBuilder()
					.setScheme("http")
					.setHost("localhost")
					.setPort(8080)
					.setPath("/A00268744Kajal_Server/rest/addressbooks").build();
			System.out.println("URI:" +uri);
			
			HttpGet httpGet = new HttpGet(uri);
			httpGet.setHeader("Accept", "application/xml");
			CloseableHttpClient httpClient = HttpClients.createDefault();
			response = httpClient.execute(httpGet);	
		
			HttpEntity entity = response.getEntity();
			String text = EntityUtils.toString(entity);
			System.out.println(text);
			
			ArrayList<AddressBook> addressbookList = new ParseAddressbook().doParseAddressBooks(text);
			System.out.println("-------------------------------------------");
			System.out.print("Returned List:"  + addressbookList);

			for(AddressBook addressbook:addressbookList) {
				System.out.println("Id:" +addressbook.getId());
				System.out.println("First Name:" +addressbook.getFname());
				System.out.println("Last Name:" +addressbook.getLname());
				System.out.println("Mobile:" +addressbook.getMobile());
				System.out.println("Gender:" +addressbook.getGender());
				System.out.println("Address:" +addressbook.getAddress());
				System.out.println("City:" +addressbook.getCity());
				System.out.println("Email:" +addressbook.getEmail());
			}	
			return addressbookList;
		} finally {
			response.close();
		}
	}
	

}

