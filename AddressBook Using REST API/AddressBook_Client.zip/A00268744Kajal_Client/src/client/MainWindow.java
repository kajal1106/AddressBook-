package client;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.UIManager;
import javax.swing.JComboBox;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.hsqldb.HsqlException;

import au.com.bytecode.opencsv.CSVWriter;

import javax.swing.JLayeredPane;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.border.LineBorder;
import javax.swing.JTextField;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.GridLayout;
import javax.swing.border.EtchedBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.JTable;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.JTextArea;
import java.awt.CardLayout;
import java.awt.Choice;

import javax.swing.ImageIcon;
import java.awt.event.ItemListener;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.awt.event.ItemEvent;
import javax.swing.JList;
import javax.swing.AbstractButton;
import javax.swing.AbstractListModel;
import javax.swing.JToggleButton;
import javax.swing.JRadioButton;

public class MainWindow extends JFrame {

	private JPanel contentPane;
	private JTextField id;
	private JTextField fname;
	private JTextField lname;
	private JTextField mobile;
	private JTextField email;
	private JTextArea address;
	private JTextField city;
	private JRadioButton female;
	private JRadioButton male;
	private JTable table_1;
	private ArrayList<AddressBook> addressbookList;
	/**
	 * Launch the application.
	 * @return 
	 */

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainWindow frame = new MainWindow();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		});
	}

	/**
	 * Create the frame.
	 * @return 
	 */


	private void groupButton( ) {

		ButtonGroup bg1 = new ButtonGroup( );

		bg1.add(male);
		bg1.add(female);

	}
	public void show_user(){
		String[] columnnames = {"Id","Fname","Lname","Mobile","Gender","Address","City","Email"};
    	DefaultTableModel model = new DefaultTableModel();
		model.setColumnIdentifiers(columnnames);
		table_1.setModel(model);
		
		AddressbookClient addressbookClient = new AddressbookClient();
		try {
			addressbookList = addressbookClient.getContacts();
		} catch (IOException | URISyntaxException e) {
			JOptionPane.showMessageDialog(null, e);
		}
		for(AddressBook addressbook:addressbookList) {
			model.addRow(new Object[] {
					addressbook.getId(),addressbook.getFname(),
					addressbook.getLname(),addressbook.getMobile(),
					addressbook.getGender(),addressbook.getAddress(),
					addressbook.getCity(),addressbook.getEmail()
					});
		}	
	}
	public MainWindow() throws HsqlException, Exception {

		groupButton( ) ;

		setTitle("Address Book");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 981, 610);
		contentPane = new JPanel();
		contentPane.setBackground(UIManager.getColor("PasswordField.selectionBackground"));
		contentPane.setBorder(new LineBorder(UIManager.getColor("PasswordField.selectionBackground"), 3, true));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLayeredPane Information = new JLayeredPane();
		Information.setBackground(UIManager.getColor("PasswordField.selectionBackground"));
		Information.setBounds(192, 10, 741, 249);
		contentPane.add(Information);

		
		JPanel utilitiess = new JPanel();
		utilitiess.setBounds(27, 10, 143, 302);
		contentPane.add(utilitiess);
		utilitiess.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "My Utilities", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(128, 0, 0)));
		utilitiess.setLayout(new CardLayout(0, 0));

		JPanel utilities = new JPanel();
		utilitiess.add(utilities, "name_678317210038700");
		Information.setLayer(utilities, 1);
		Information.setLayout(new CardLayout(0, 0));

		JPanel panel_4 = new JPanel();
		panel_4.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Personal Information", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(128, 0, 0)));
		Information.add(panel_4, "name_678298822457000");
		panel_4.setLayout(new CardLayout(0, 0));

		JPanel panel_2 = new JPanel();
		panel_4.add(panel_2, "name_678229091861400");
		panel_2.setBorder(new LineBorder(UIManager.getColor("PasswordField.selectionBackground"), 2, true));
		panel_2.setBackground(UIManager.getColor("PasswordField.selectionBackground"));
		panel_2.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(0, 21, 96, 28);
		panel_2.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("First Name\r\n");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setBounds(0, 60, 96, 28);
		panel_2.add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Last Name");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setBounds(0, 98, 96, 28);
		panel_2.add(lblNewLabel_3);

		id = new JTextField();
		id.setEditable(true);
		
		id.setFont(new Font("Tahoma", Font.BOLD, 15));
		id.setBounds(132, 22, 179, 28);
		panel_2.add(id);
		id.setColumns(10);

		fname = new JTextField();
		fname.setFont(new Font("Tahoma", Font.PLAIN, 15));
		fname.setBounds(132, 61, 179, 28);
		panel_2.add(fname);
		fname.setColumns(10);

		lname = new JTextField();
		lname.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lname.setBounds(132, 99, 179, 28);
		panel_2.add(lname);
		lname.setColumns(10);

		JLabel lblNewLabel_4 = new JLabel("Mobile #");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setBounds(0, 143, 102, 28);
		panel_2.add(lblNewLabel_4);

		JLabel lblNewLabel_6 = new JLabel("Email Address");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_6.setBounds(321, 185, 112, 28);
		panel_2.add(lblNewLabel_6);

		mobile = new JTextField();
		mobile.setFont(new Font("Tahoma", Font.PLAIN, 15));
		mobile.setBounds(132, 146, 179, 28);
		panel_2.add(mobile);
		mobile.setColumns(10);

		JLabel lblNewLabel_7 = new JLabel("Home Address");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_7.setForeground(new Color(255, 255, 255));
		lblNewLabel_7.setBounds(314, 21, 119, 28);
		panel_2.add(lblNewLabel_7);

		JTextArea address = new JTextArea();
		address.setBounds(443, 25, 244, 101);
		panel_2.add(address);

		email = new JTextField();

		email.setColumns(10);
		email.setBounds(443, 185, 244, 28);
		panel_2.add(email);

		JLabel lblGender = new JLabel("Gender");
		lblGender.setForeground(Color.WHITE);
		lblGender.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblGender.setBounds(0, 185, 102, 28);
		panel_2.add(lblGender);

		city = new JTextField();
		city.setColumns(10);
		city.setBounds(443, 143, 244, 28);
		panel_2.add(city);

		JLabel lblCity = new JLabel("City");
		lblCity.setForeground(Color.WHITE);
		lblCity.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblCity.setBounds(321, 143, 112, 28);
		panel_2.add(lblCity);

		JRadioButton male = new JRadioButton("Male");
		//male.setActionCommand("male");
		male.setHorizontalAlignment(SwingConstants.CENTER);
		male.setBackground(Color.WHITE);
		male.setFont(new Font("Tahoma", Font.BOLD, 15));
		male.setBounds(131, 191, 84, 28);
		panel_2.add(male);

		JRadioButton female = new JRadioButton("Female");
		//female.setActionCommand("male");
		female.setHorizontalAlignment(SwingConstants.CENTER);
		female.setBackground(Color.WHITE);
		female.setFont(new Font("Tahoma", Font.BOLD, 15));
		female.setBounds(227, 191, 84, 28);
		panel_2.add(female);
		utilities.setBorder(new LineBorder(UIManager.getColor("PasswordField.selectionBackground"), 3, true));
		utilities.setBackground(UIManager.getColor("PasswordField.selectionBackground"));
		utilities.setLayout(new GridLayout(6, 0, 2, 2));



		JButton btnAdd = new JButton("POST");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean result1=false;
				boolean result2=false;
				try {
					result1 =AddressBook.validateId(id.getText());
				} catch (AddressBookExceptionHandler e1) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					JOptionPane.showMessageDialog(null, e1, "Error",JOptionPane.ERROR_MESSAGE);
				}
				try {
					result2 = AddressBook.validateName(fname.getText());
				} catch (AddressBookExceptionHandler e1) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					JOptionPane.showMessageDialog(null, e1, "Error",JOptionPane.ERROR_MESSAGE);
				}
				if(result1==true&&result2==true)
				{
					
				
					int id2 = Integer.parseInt(id.getText().trim());
					String firstname = fname.getText();
					String lastname = lname.getText();
					int mobile1 = Integer.parseInt(mobile.getText().trim());
					String gender ="";
					if(male.isSelected()) 
						gender=male.getText();
					else if(female.isSelected()) 
						gender=female.getText();
					String city1 = city.getText();
					String address1 = address.getText();
					String email1 = email.getText();
					
					URI uri = null;
					try {
						 uri = new URIBuilder()
								.setScheme("http")
								.setHost("localhost")
								.setPort(8080)
								.setPath("/A00268744Kajal_Server/rest/addressbooks").build();
						//POST
						HttpPost httpPost = new HttpPost(uri);
						httpPost.setHeader("Accept", "text/html");
						CloseableHttpClient Client = HttpClients.createDefault();
						
						List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
						nameValuePairs.add(new BasicNameValuePair("id",String.valueOf(id2)));
						nameValuePairs.add(new BasicNameValuePair("fname",firstname));
						nameValuePairs.add(new BasicNameValuePair("lname",lastname));
						nameValuePairs.add(new BasicNameValuePair("mobile",String.valueOf(mobile1)));
						nameValuePairs.add(new BasicNameValuePair("gender",gender));
						nameValuePairs.add(new BasicNameValuePair("address",address1));
						nameValuePairs.add(new BasicNameValuePair("city",city1));
						nameValuePairs.add(new BasicNameValuePair("email",email1));

						httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
						System.out.println("Sending Request........");
						CloseableHttpResponse response1 = Client.execute(httpPost);
						System.out.println("Response:" + response1.toString());
						show_user();
						JOptionPane.showMessageDialog(null, "Contacts Registered Succesfully!!!");
						
					
				} catch (URISyntaxException | IOException e1) {
					System.out.println("Error: "+e1);  
					JOptionPane.showMessageDialog(null, e1);
				
					}
					
				}
			}
		});

		btnAdd.setFont(new Font("Tahoma", Font.BOLD, 15));
		utilities.add(btnAdd);

		JButton btnUpdate = new JButton("PUT");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean result1=false;
				boolean result2=false;
				try {
					result1 =AddressBook.validateId(id.getText());
				} catch (AddressBookExceptionHandler e1) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					JOptionPane.showMessageDialog(null, e1, "Error",JOptionPane.ERROR_MESSAGE);
				}
				try {
					result2 = AddressBook.validateName(fname.getText());
				} catch (AddressBookExceptionHandler e1) {
					// TODO Auto-generated catch block
					//e.printStackTrace();
					JOptionPane.showMessageDialog(null, e1, "Error",JOptionPane.ERROR_MESSAGE);
				}
				if(result1==true&&result2==true)
				{
				int id2 = Integer.parseInt(id.getText().trim());
				String firstname = fname.getText();
				String lastname = lname.getText();
				int mobile1 = Integer.parseInt(mobile.getText().trim());
				 String gender ="";
					if(male.isSelected()) 
						gender=male.getText();
					else if(female.isSelected()) 
						gender=female.getText();
				String address1 = address.getText();
				String city1 = city.getText();
				String email1 = email.getText();
				
				URI uri = null;
				try {
					 uri = new URIBuilder()
							.setScheme("http")
							.setHost("localhost")
							.setPort(8080)
							.setPath("/A00268744Kajal_Server/rest/addressbooks/"+id2).build();
					//PUT
						HttpPut httpPut = new HttpPut(uri);
						httpPut.setHeader("Accept", "text/html");
						CloseableHttpClient ClientPut = HttpClients.createDefault();
						
						List<NameValuePair> nameValuePairsPut = new ArrayList<NameValuePair>(1);
						nameValuePairsPut.add(new BasicNameValuePair("id",String.valueOf(id2)));
						nameValuePairsPut.add(new BasicNameValuePair("fname",firstname));
						nameValuePairsPut.add(new BasicNameValuePair("lname",lastname));
						nameValuePairsPut.add(new BasicNameValuePair("mobile",String.valueOf(mobile1)));
						nameValuePairsPut.add(new BasicNameValuePair("gender",gender));
						nameValuePairsPut.add(new BasicNameValuePair("address",address1));
						nameValuePairsPut.add(new BasicNameValuePair("city",city1));
						nameValuePairsPut.add(new BasicNameValuePair("email",email1));

						httpPut.setEntity(new UrlEncodedFormEntity(nameValuePairsPut));
						System.out.println("Sending PUT Request........");
						CloseableHttpResponse responsePut = ClientPut.execute(httpPut);
						System.out.println("Response:" + responsePut.toString());
						show_user();
						JOptionPane.showMessageDialog(null, "Addressbook Modified Succesfully!!!");
								
				
			} catch (URISyntaxException | IOException e1) {
				JOptionPane.showMessageDialog(null, e1);
			}
				}
				
			
		}
			
		});
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 15));
		utilities.add(btnUpdate);

		JButton btnDelete = new JButton("DELETE");
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int id2 = Integer.parseInt(id.getText().trim());
				URI uri = null;
				try {
					 uri = new URIBuilder()
							.setScheme("http")
							.setHost("localhost")
							.setPort(8080)
							.setPath("/A00268744Kajal_Server/rest/addressbooks/"+id2).build();
						
					 //DELETE
						HttpDelete httpDelete = new HttpDelete(uri);
						httpDelete.setHeader("Accept", "text/html");
						CloseableHttpClient ClientDelete = HttpClients.createDefault();
							
						System.out.println("Sending Delete Request........");
						CloseableHttpResponse responsedelete = ClientDelete.execute(httpDelete);
						System.out.println("Response:" + responsedelete.toString());
						 show_user();
					 JOptionPane.showMessageDialog(null, "Contact is permanently deleted!!!");
					
			} catch (URISyntaxException | IOException e1) {
				JOptionPane.showMessageDialog(null, e1);
			}
				id.setText("");
				fname.setText("");
				lname.setText("");
				mobile.setText("");
				//gender.setText("");
				address.setText(""); 
				city.setText("");
				email.setText(""); 
			}
		});
		utilities.add(btnDelete);

		JButton btnView = new JButton("VIEW\r\n");
		btnView.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewWindow view = new ViewWindow();
				view.setVisible(true);
				//MainWindow.this.setVisible(false);

			}
		});
		utilities.add(btnView);

		JButton btnReset = new JButton("RESEST");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// reset text fields
				id.setText("");
				fname.setText("");
				lname.setText("");
				mobile.setText("");
				//gender.setText("");
				address.setText(""); 
				city.setText("");
				email.setText(""); 
			}
		});
		btnReset.setFont(new Font("Tahoma", Font.BOLD, 15));
		utilities.add(btnReset);

		JButton btnNewButton = new JButton("EXPORT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				writeToFile(addressbookList);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		utilities.add(btnNewButton);

		JPanel Table = new JPanel();
		Table.setLayout(null);
		Table.setBorder(new TitledBorder(null, "Database Content", TitledBorder.LEADING, TitledBorder.TOP, null,  new Color(128, 0, 0)));
		Table.setBounds(182, 269, 751, 283);
		contentPane.add(Table);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 21, 743, 252);
		Table.add(scrollPane);

		table_1 = new JTable();
		scrollPane.setViewportView(table_1);

		JPanel Export = new JPanel();
		Export.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Table Info", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(128, 0, 0)));
		Export.setBounds(27, 323, 143, 225);
		contentPane.add(Export);
		Export.setLayout(new GridLayout(0, 1, 2, 2));

		JButton Createtable = new JButton("CREATE TABLE");
		Createtable.setForeground(new Color(0, 0, 0));
		Createtable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Class.forName("org.hsqldb.jdbcDriver");
					Connection con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/OneDB", "SA", "");
					Statement stmt = con.createStatement();
					stmt.executeUpdate(
							"CREATE TABLE IF NOT EXISTS addressbook(id INTEGER IDENTITY, fname VARCHAR(32) NOT NULL, lname VARCHAR(32) NOT NULL , mobile INTEGER , gender VARCHAR(32),  address VARCHAR(220), city VARCHAR(32), email VARCHAR(32))");
					JOptionPane.showMessageDialog(null, "Table have been created successfully into the HSQL Database!");
				} catch (ClassNotFoundException | SQLException | HsqlException e1) {
					JOptionPane.showMessageDialog(null, e1);
					
				}
			}	
		});

		Createtable.setFont(new Font("Arial Black", Font.PLAIN, 11));
		Export.add(Createtable);

		JButton filltable = new JButton("FILL TABLE");
		filltable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				String[] contact1 = {"1", "Nainsha", "Singh", "894912611","Female","Croi-Oige Stdent village","Athlone","nainsha@gmail.com"};
				String[] contact2 = {"2", "Yash", "Somani", "894912601","Male","Croi-Oige Stdent village","Athlone","yash@gmail.com"};
				String[] contact3 = {"3", "Burhan", "Mullamitha", "894912618","Male","Croi-Oige Stdent village","Athlone","burhanmm@gmail.com"};
				
				String[][] contactsArr = {contact1,contact2,contact3};
				for(int i=0; i<contactsArr.length; i++) {
					postData(contactsArr[i][0],contactsArr[i][1],contactsArr[i][2],contactsArr[i][3],contactsArr[i][4],
							contactsArr[i][5],contactsArr[i][6],contactsArr[i][7]);
				}
				show_user();

			}
		});
		filltable.setFont(new Font("Arial Black", Font.PLAIN, 14));
		Export.add(filltable);

		
		
		JButton cleartable = new JButton("CLEAR TABLE");
		cleartable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				try {
					Class.forName("org.hsqldb.jdbcDriver");
					Connection con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/OneDB", "SA", "");
					Statement stmt = con.createStatement();
					stmt.executeUpdate(
							"DROP TABLE addressbook ");
					JOptionPane.showMessageDialog(null, "Table have been cleared successfully from the HSQL Database!");
					show_user();
				} catch (ClassNotFoundException | SQLException | HsqlException e1) {
					JOptionPane.showMessageDialog(null, e1);
					
				}
			}
			});
		cleartable.setFont(new Font("Arial Black", Font.PLAIN, 11));
		Export.add(cleartable);

		JButton projectInfo = new JButton("PROJECT Info.");
		projectInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Project was created by:"+"\nKajal Singh"+"\nA00268744");
			}
		});
		projectInfo.setFont(new Font("Arial Black", Font.PLAIN, 12));
		Export.add(projectInfo);
		show_user();
	}
	public void postData(String id, String fname, String lname, String number, String gender, String address, String city, String email) {
		URI uri = null;
		try {
			 uri = new URIBuilder()
					.setScheme("http")
					.setHost("localhost")
					.setPort(8080)
					.setPath("/A00268744Kajal_Server/rest/addressbooks").build();
			//POST
			HttpPost httpPost = new HttpPost(uri);
			httpPost.setHeader("Accept", "text/html");
			CloseableHttpClient Client = HttpClients.createDefault();
			
			List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(1);
			nameValuePairs.add(new BasicNameValuePair("id",id));
			nameValuePairs.add(new BasicNameValuePair("fname",fname));
			nameValuePairs.add(new BasicNameValuePair("lname",lname));
			nameValuePairs.add(new BasicNameValuePair("mobile",number));
			nameValuePairs.add(new BasicNameValuePair("gender",gender));
			nameValuePairs.add(new BasicNameValuePair("address",address));
			nameValuePairs.add(new BasicNameValuePair("city",city));
			nameValuePairs.add(new BasicNameValuePair("email",email));

			httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			System.out.println("Sending Request........");
			CloseableHttpResponse response1 = Client.execute(httpPost);
			System.out.println("Response:" + response1.toString());
			
		
		
	} catch (URISyntaxException | IOException e1) {
		System.out.println("Error: "+e1);  
		JOptionPane.showMessageDialog(null, e1);
	}
	}
	protected void writeToFile(ArrayList<AddressBook> addressbookList) {
		JLabel lblNewLabel = new JLabel("Address Book");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Arial Black", Font.BOLD, 40));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(216, 21, 542, 55);
		contentPane.add(lblNewLabel);

		// TODO Auto-generated method stub
		String fileName = "Data/addressbook.csv";
		JOptionPane.showMessageDialog(null, "Details are successfully generated in Data.csv");

		try(
			FileOutputStream fos = new FileOutputStream(fileName);
			OutputStreamWriter osw = new OutputStreamWriter(fos, StandardCharsets.UTF_8);
			CSVWriter writer = new CSVWriter(osw)) {
		    	String[] columns = {"ID","Fname","Lname","Mobile","Gender","Address","City","Email"};
		    	writer.writeNext(columns);	
			
		    	for(AddressBook addressbook:addressbookList) {
					String[] fields = {
							String.valueOf(addressbook.getId()),String.valueOf(addressbook.getFname()),
							String.valueOf(addressbook.getLname()),String.valueOf(addressbook.getMobile()),
							String.valueOf(addressbook.getGender()),String.valueOf(addressbook.getAddress()),
							String.valueOf(addressbook.getCity()),String.valueOf(addressbook.getEmail())
							};
				
		    	
		    	writer.writeNext(fields);
		}
			}catch(IOException e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e);	
		}
	}
}
