package client;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;



public class ParseAddressbook {

	boolean inAddressbooks = false;
	boolean inAddressbook = false;
	boolean inId = false;
	boolean inFname = false;
	boolean inLname = false;
	boolean inMobile = false;
	boolean inGender = false;
	boolean inAddress = false;
	boolean inCity = false;
	boolean inEmail = false;
	
	AddressBook currentAddressbook;
	
	ArrayList<AddressBook> currentAddressbookList;
	public ArrayList<AddressBook> doParseAddressBooks(String s) {
		// TODO Auto-generated method stub
		
		try {
			XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
			XmlPullParser pullParser = factory.newPullParser();
			pullParser.setInput(new StringReader(s));
			processDocument(pullParser);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return currentAddressbookList;
	}
	private void processDocument(XmlPullParser pullParser)throws XmlPullParserException, IOException {
		// TODO Auto-generated method stub
		int eventType = pullParser.getEventType();
		do {
			if(eventType== XmlPullParser.START_DOCUMENT) {
				System.out.println("Start Document");
			}else if(eventType== XmlPullParser.END_DOCUMENT) {
				System.out.println("End Document");
			}else if(eventType== XmlPullParser.START_TAG) {
				processStartElement(pullParser);	
			}else if(eventType== XmlPullParser.END_TAG) {
				ProcessEndElement(pullParser);
			}else if(eventType== XmlPullParser.TEXT) {
				processText(pullParser);
		}
			eventType =pullParser.next();
	} while(eventType != XmlPullParser.END_DOCUMENT);

	}
	private void processText(XmlPullParser event) throws XmlPullParserException {
		// TODO Auto-generated method stub
		System.out.print("Event:" +event.getText());
		if(inId) {
			String s = event.getText();
			currentAddressbook.setId(Integer.parseInt(s));
		}
		if(inFname) {
			String s = event.getText();
			currentAddressbook.setFname(s);
		}
		if(inLname) {
			String s = event.getText();
			currentAddressbook.setLname(s);
		}
		if(inMobile) {
			String s = event.getText();
			currentAddressbook.setMobile(Integer.parseInt(s));
		}
		if(inGender) {
			String s = event.getText();
			currentAddressbook.setGender(s);
		}
		if(inAddress) {
			String s = event.getText();
			currentAddressbook.setAddress(s);
		}
		if(inCity) {
			String s = event.getText();
			currentAddressbook.setCity(s);
		}
		if(inEmail) {
			String s = event.getText();
			currentAddressbook.setEmail(s);
		}
	}
	private void ProcessEndElement(XmlPullParser event) {
		// TODO Auto-generated method stub
		String name=event.getName();
		if(name.equals("addressBooks")) {
			inAddressbooks=false;
		}
		else if(name.equals("addressbook")) {
			inAddressbook=false;
			currentAddressbookList.add(currentAddressbook);
		}
		else if(name.equals("id")) {
			inId=false;
		}
		else if(name.equals("fname")) {
			inFname=false; 
		}
		else if(name.equals("lname")) {
			inLname=false; 
		}
		else if(name.equals("mobile")) {
			inMobile=false; 
		}
		else if(name.equals("gender")) {
			inGender=false; 
		}
		else if(name.equals("address")) {
			inAddress=false; 
		}
		else if(name.equals("city")) {
			inCity=false; 
		}
		else if(name.equals("email")) {
			inEmail=false; 
		}
	}
	private void processStartElement(XmlPullParser event) {
		// TODO Auto-generated method stub
		String name=event.getName();
		System.out.println("START EVENT:" +name);
		if(name.equals("addressBooks")) {
			inAddressbooks=true;
			currentAddressbookList = new ArrayList<AddressBook>();
		}
		else if(name.equals("addressbook")) {
			inAddressbook=true;
			currentAddressbook = new AddressBook();
		}
		else if(name.equals("id")) {
			inId=true;
		}
		else if(name.equals("fname")) {
			inFname=true; 
		}
		else if(name.equals("lname")) {
			inLname=true; 
		}
		else if(name.equals("mobile")) {
			inMobile=true; 
		}
		else if(name.equals("gender")) {
			inGender=true; 
		}
		else if(name.equals("address")) {
			inAddress=true; 
		}
		else if(name.equals("city")) {
			inCity=true; 
		}
		else if(name.equals("email")) {
			inEmail=true; 
		}
	}
	
}
